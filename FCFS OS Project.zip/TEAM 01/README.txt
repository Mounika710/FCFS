First Come First Serve project
           Writing a python program which accepts the user input on process id, arrival time, burst time .After Receiving this according to First-come, First-Served algorithm calculating the each processes .Then calculate each process waiting time and average waiting time .Similarly Turn around time and average turn around time also calculating the completion time of each process.
             
                We choose python programming language for simulating the two concepts of calculating the Average waiting time and Average Turn Around time of the processes and representing the result it a graphical manner(Gantt  chart).

                